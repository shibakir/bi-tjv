package cz.cvut.fit.tjv.social_network.repository;

import cz.cvut.fit.tjv.social_network.domain.EntityWithId;

import java.util.*;

public abstract class AbstractRepository<E extends EntityWithId, ID> {

    private Map<ID, E> db = new HashMap<>(); // database

    public Optional<E> getById(ID id) {
        Optional<E> result = Optional.of(db.get(id));
        return result;
    }

    public E save(E entity) {
        db.put((ID) entity.getId(), entity);
        return entity;
    }
}
