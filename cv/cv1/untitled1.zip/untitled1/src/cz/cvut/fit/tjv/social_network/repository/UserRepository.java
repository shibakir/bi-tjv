package cz.cvut.fit.tjv.social_network.repository;

import cz.cvut.fit.tjv.social_network.domain.User;

public class UserRepository extends AbstractRepository<User, String> {

    @Override
    public User getById(String s) {
        return null;
    }
}
