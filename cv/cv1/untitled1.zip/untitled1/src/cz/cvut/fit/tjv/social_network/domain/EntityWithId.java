package cz.cvut.fit.tjv.social_network.domain;

public interface EntityWithId<ID> {
    ID getId();


}
