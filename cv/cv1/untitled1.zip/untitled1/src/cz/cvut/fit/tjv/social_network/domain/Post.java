package cz.cvut.fit.tjv.social_network.domain;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Post implements EntityWithId<Long> {

    private Long id;
    private User author;
    private Post replyTo;

    private String textContents;
    private final Set<User> likes = new HashSet<>();

    public Post() {
    }

    public Post(Long id, User author, Post replyTo, String textContents) {
        this.id = id;
        this.author = author;
        this.replyTo = replyTo;
        this.textContents = textContents;

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getAuthor() {
        return author;
    }

    public void setAuthor(User author) {
        this.author = author;
    }

    public Post getReplyTo() {
        return replyTo;
    }

    public void setReplyTo(Post replyTo) {
        this.replyTo = replyTo;
    }

    public String getTextContents() {
        return textContents;
    }

    public void setTextContents(String textContents) {
        this.textContents = textContents;
    }

    public Collection<User> getLikes() {
        return Collections.unmodifiableCollection(likes);
    }
}
