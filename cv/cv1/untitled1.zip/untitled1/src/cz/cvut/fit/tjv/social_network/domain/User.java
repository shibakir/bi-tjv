package cz.cvut.fit.tjv.social_network.domain;

import java.io.Serializable;

public class User implements EntityWithId<String>, Serializable {

    private String username;
    private String realName;

    public User(String username, String realName) {
        this.username = username;
        this.realName = realName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    @Override
    public String getId() {
        return getUsername();
    }
}
