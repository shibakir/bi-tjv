package cz.cvut.fit.tjv.social_network.repository;

import cz.cvut.fit.tjv.social_network.domain.EntityWithId;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class AbstractRepository<E extends EntityWithId, ID> {

    private Map<ID, E> db = new HashMap<>(); // database

    public E getById(ID id) {
        return db.get(id);
    }

    public E save(E entity) {
        db.put((ID) entity.getId(), entity);
        return entity;
    }
}
